export default {
    CARD: 'card',
}
